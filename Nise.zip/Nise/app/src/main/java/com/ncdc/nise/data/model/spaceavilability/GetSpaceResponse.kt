package com.ncdc.nise.data.model.spaceavilability

data class GetSpaceResponse(
    val status: Boolean,
    val message: String,
    val `data`: SpaceAvilableData


)