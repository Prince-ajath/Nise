package com.ncdc.nise.interfaces

interface Backpressedlistener {

    fun onBackPressed(position:Int)
}