/*
package com.ncdc.nise.ui.energy

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ncdc.nise.R


class EnergyAssesmentActvity :AppCompatActivity(){



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_energy_assements)
    }


}*/
