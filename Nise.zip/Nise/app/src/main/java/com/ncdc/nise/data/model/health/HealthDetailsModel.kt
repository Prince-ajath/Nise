package com.ncdc.nise.data.model.health

data class HealthDetailsModel(
    val status: Boolean,
    val message: String,
    val `data`: HealthData


)