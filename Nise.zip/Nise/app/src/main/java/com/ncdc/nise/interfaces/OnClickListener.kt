package com.ncdc.nise.interfaces

interface OnClickListener {
    fun onUpdate(surveyId:Int)
}