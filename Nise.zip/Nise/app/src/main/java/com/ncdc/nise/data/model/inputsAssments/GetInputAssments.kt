package com.ncdc.nise.data.model.inputsAssments

data class GetInputAssments(
    val status: Boolean,
    val message: String,
    val `data`: InputAssmentsData

)