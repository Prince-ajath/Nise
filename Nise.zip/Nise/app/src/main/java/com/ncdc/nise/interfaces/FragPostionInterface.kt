package com.ncdc.nise.interfaces

interface FragPostionInterface {
     fun onItemClick(position: Int)

}