package com.ncdc.nise.ui.register.model

data class AuthData(
    val id: String,
    val username: String,
    val active:Int
)