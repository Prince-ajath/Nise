package com.ncdc.nise.interfaces

interface HomeListener {
    fun deleteItem(id:Int)
}