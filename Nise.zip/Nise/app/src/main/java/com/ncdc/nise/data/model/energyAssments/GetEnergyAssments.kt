package com.ncdc.nise.data.model.energyAssments

data class GetEnergyAssments(
    val status: Boolean,
    val message: String,
    val `data`: EnergyAssmentData


)