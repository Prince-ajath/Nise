package com.ncdc.nise.ui.survey.model

data class updateResponse(
    val status: Boolean,
    val message: String

)